package com.example.movieappmvvp.network

import com.example.movieappmvvp.model.MovieResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface ApiService {

    @GET("popular")
    suspend fun getAllMovies(
        @Query("api_key") api_key: String = "79c8f4659a3fbb27a6f02497b1812d77"
    ): Response<MovieResponse>

    @GET("search")
    suspend fun searchMovie(
        @Query("query") query: String,
        @Query("api_key") api_key: String = "79c8f4659a3fbb27a6f02497b1812d77"
    ): Response<MovieResponse>
}