package com.example.movieappmvvp.viewmodel

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.movieappmvvp.model.MovieResponse
import com.example.movieappmvvp.network.RetrofitClient
import com.example.movieappmvvp.repository.MainRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(private val application: Application): ViewModel() {
    private val repository = MainRepository(RetrofitClient.provideRetrofit())

    fun getAllMovies(): LiveData<List<com.example.movieappmvvp.model.Result>>{
        val movies: MutableLiveData<List<com.example.movieappmvvp.model.Result>> = MutableLiveData()

        try {
            viewModelScope.launch (Dispatchers.IO){
                if (repository.getAllMovies().isSuccessful){
                    movies.postValue(repository.getAllMovies().body()?.results)
                }else{
                    withContext(Dispatchers.Main){
                        Toast.makeText(application, repository.getAllMovies().message(), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }catch (e: java.lang.Exception){
            Toast.makeText(application,e.toString(), Toast.LENGTH_SHORT).show()
        }
        return movies
    }

    fun searchMovie(text: String): LiveData<List<com.example.movieappmvvp.model.Result>>{
        val movies: MutableLiveData<List<com.example.movieappmvvp.model.Result>> = MutableLiveData()

        try {
            viewModelScope.launch(Dispatchers.IO) {
                if (repository.searchMovie(text).isSuccessful){
                    movies.postValue(repository.getAllMovies().body()?.results)
                }else{
                    withContext(Dispatchers.Main){
                        Toast.makeText(application, repository.searchMovie(text).message(), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }catch (e: java.lang.Exception){
            Toast.makeText(application, e.toString(), Toast.LENGTH_SHORT).show()
        }

        return movies
    }
}